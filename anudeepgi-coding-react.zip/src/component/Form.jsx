import React, { Component, useState } from 'react'
import ListData from './List';

function Form() {
   let [formData,setFormData] =  useState({});
   let [list,setListData] = useState({...window.localStorage});

   let onChangeData = (e) =>{
    formData[e.target.name] = e.target.value;
    setFormData(formData);
   }

   const deleteFun = (e) => {
    window.localStorage.removeItem(e.target.name)
    setListData({...window.localStorage})
    }

    const editFun = (e) => {

        console.log(e.target.name);

    }

   let addToLocal = () =>{
    window.localStorage.setItem(Math.random(),JSON.stringify(formData))
    setListData({...window.localStorage})
   }


    return (
        <div className='form'>
            <input name="fname" type="text" onChange={onChangeData} />
            <input name="lname" type="text" onChange={onChangeData} />
            <input name="dob" type="text" onChange={onChangeData} />
            <input name="designation" type="text" onChange={onChangeData} />
            <input name="profilephoto" type="text" onChange={onChangeData} />
            <input name="experience" type="text" onChange={onChangeData} />
            <button onClick={addToLocal}>Add</button>
            <br/>
            <br/>
            <br/>
            <br/>
            <ListData item={list} delete={deleteFun}/>
        </div>
    );

}

export default Form;