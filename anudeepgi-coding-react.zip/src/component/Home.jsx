import React, { Component } from 'react'
import Form from './Form';

function Home() {

    return (
        <>
        <Form/>
        </>
        
    );

}

export default Home;