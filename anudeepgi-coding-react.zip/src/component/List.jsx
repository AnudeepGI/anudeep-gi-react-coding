import React, { Component } from 'react'

function ListData(props) {


    const editFun = (e) => {
        console.log(e.target.name);
    }


    return (
        Object.keys(props.item).map((val)=> {
            console.log(val);
            let data = JSON.parse(window.localStorage.getItem(val));
           return(
            <>
                <span>{data.fname}</span> 
                <span>{data.lname}</span>
                <span>{data.dob}</span>
                <span>{data.designation}</span>
                <span>{data.profilephoto}</span>
                <span>{data.experience}</span>
                <span><button name={val} onClick={editFun}>edit</button></span>
                <span><button name={val} onClick={props.delete}>Delete</button>                
                
                </span>
                <br/>
            </>
           );
            
        })
    );

}

export default ListData;